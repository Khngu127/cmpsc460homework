public class Parser {
    public static final int OP = 10;
    public static final int RELOP = 11;
    public static final int LPAREN = 12;
    public static final int RPAREN = 13;
    public static final int SEMI = 14;
    public static final int COMMA = 15;
    public static final int INT = 16;
    public static final int NUM = 17;
    public static final int ID = 18;
    public static final int PRINT = 19;
    public static final int COLON = 21;
    public static final int EQUAL = 22;
    public static final int FUNC = 23;   // func
    public static final int TYPEOF = 24; // ::
    public static final int ASSIGN = 25; // :=
    public static final int VAR = 26;    // var
    public static final int BEGIN = 27;  // begin
    public static final int END = 28;    // end
    public static final int VOID = 29;
    public static final int IF = 30;
    public static final int THEN = 31;
    public static final int ELSE = 32;
    public static final int WHILE = 33;

    Compiler compiler;
    Lexer lexer;
    public ParserVal yylval;

    public Parser(java.io.Reader r, Compiler compiler) throws Exception {
        this.compiler = compiler;
        this.lexer = new Lexer(r, this);
        this.yylval = new ParserVal();

    }

    public int yyparse() throws Exception {
        while (true) {
            int token = lexer.yylex();
            Object attr = yylval.obj;
            String tokenname;

            switch (token) {
                case 0:
                    // EOF is reached
                    System.out.println("Success!");
                    return 0;
                case -1:
                    // lexical error is found
                    System.out.println("Error! There is a lexical error at " + lexer.lineno + ":" + lexer.column + ".");
                    return -1;
                case NUM:
                    tokenname = "NUM";
                    break;
                case ID:
                    tokenname = "ID";
                    break;
                case COLON:
                    tokenname = "COLON";
                    break;
                case EQUAL:
                    tokenname = "EQUAL";
                    break;
                case OP:
                    tokenname = "OP";
                    break;
                case RELOP:
                    tokenname = "RELOP";
                    break;
                case LPAREN:
                    tokenname = "LPAREN";
                    break;
                case RPAREN:
                    tokenname = "RPAREN";
                    break;
                case SEMI:
                    tokenname = "SEMI";
                    break;
                case COMMA:
                    tokenname = "COMMA";
                    break;
                case INT:
                    tokenname = "INT";
                    break;
                case PRINT:
                    tokenname = tokenToString(token);
                    break;
                case FUNC:
                    tokenname = "FUNC";
                    break;
                case TYPEOF:
                    tokenname = "TYPEOF";
                    break;
                case ASSIGN:
                    tokenname = "ASSIGN";
                    break;
                case VAR:
                    tokenname = "VAR";
                    break;
                case END:
                    tokenname = "END";
                    break;
                default:
                    tokenname = "BEGIN";
                    break;
            }

            System.out.println("<" + tokenname + ", token-attr:\"" + attr + "\", " + lexer.lineno + ":" + lexer.getLexemeStartColumn() + ">");

            //System.out.println(attr);
        }
    }

    public String tokenToString(int token) {
        switch (token) {
            case Parser.OP:
                return "OP";
            case Parser.RELOP:
                return "RELOP";
            case Parser.LPAREN:
                return "LPAREN";
            case Parser.RPAREN:
                return "RPAREN";
            case Parser.SEMI:
                return "SEMI";
            case Parser.COMMA:
                return "COMMA";
            case Parser.INT:
                return "INT";
            case Parser.NUM:
                return "NUM";
            case Parser.ID:
                return "ID";
            case Parser.PRINT:
                return "PRINT";
            case Parser.COLON:
                return "COLON";
            case Parser.EQUAL:
                return "EQUAL";
            case Parser.FUNC:
                return "FUNC";
            case Parser.TYPEOF:
                return "TYPEOF";
            case Parser.ASSIGN:
                return "ASSIGN";
            case Parser.VAR:
                return "VAR";
            case Parser.BEGIN:
                return "BEGIN";
            default:
                return "END";
        }
    }
}