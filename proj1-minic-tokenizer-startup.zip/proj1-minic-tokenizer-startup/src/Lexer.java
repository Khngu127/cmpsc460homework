public class Lexer {
    private static final char EOF = 0;

    private Parser yyparser; // parent parser object
    private java.io.Reader reader; // input stream
    public int lineno; // line number
    public int column; // column
    private int lexemeStartColumn;  // Variable to store the start position of the lexeme

    private StringBuilder lexemeBuffer = new StringBuilder(); // Current lexeme buffer
    private StringBuilder doubleBuffer = new StringBuilder(); // Double buffer

    public Lexer(java.io.Reader reader, Parser yyparser) throws Exception {
        this.reader = reader;
        this.yyparser = yyparser;
        lineno = 1;
        column = 1;
        lexemeStartColumn = 1;  // Initialize lexemeStartColumn
    }
    public int getLexemeStartColumn() {
        return lexemeStartColumn;
    }
    public String NextChar() throws Exception {
        int data = reader.read();
        if (data == -1) {
            return String.valueOf(EOF);
        }
        // System.out.println("Data: " + data);
        String c = String.valueOf((char) data);

        if (c.equals("\n")) {
            lineno++;
            column = 1; // Reset column count for a new line
        } else {
            if (lexemeBuffer.length() == 0) {
                lexemeStartColumn = column;  // Set the lexeme start position
            }
            // System.out.print("Column No: " + column + ", ");
            column++;  // Increment column for each character
        }

        // System.out.println("NextChar: " + c); // Add this line for debugging

        return c;
    }

    public int Fail() {
        return -1;
    }
    private int checkKeyword(String lexeme) {
        // Determine the token for a keyword
        switch (lexeme) {
            case "int":
                return Parser.INT;
            case "print":
                return Parser.PRINT;
            case "var":
                return Parser.VAR;
            case "func":
                return Parser.FUNC;
            case "if":
                return Parser.IF;
            case "then":
                return Parser.THEN;
            case "else":
                return Parser.ELSE;
            case "while":
                return Parser.WHILE;
            case "void":
                return Parser.VOID;
            case "begin":
                return Parser.BEGIN;
            case "end":
                return Parser.END;
            // Add cases for other keywords
            default:
                return -1; // Not a keyword
        }
    }
    private int checkSymbol(String symbol) throws Exception {
        // System.out.println("Symbol: " + symbol);
        // Determine the token for a symbol
        switch (symbol) {
            case "(":
                return Parser.LPAREN;
            case ")":
                return Parser.RPAREN;
            case ":=":
                yyparser.yylval = new ParserVal(":=");
                return Parser.ASSIGN;
            case "::":
                yyparser.yylval = new ParserVal("::");
                return Parser.TYPEOF;
            case ":":
                return Parser.COLON;
            case ";":
                return Parser.SEMI;
            case ",":
                return Parser.COMMA;
            case "<=":
                yyparser.yylval = new ParserVal("<=");
                return Parser.RELOP;
            case "<>":
                yyparser.yylval = new ParserVal("<>");
                return Parser.RELOP;
            case "<":
                yyparser.yylval = new ParserVal("<");
                return Parser.RELOP;
            case ">=":
            case ">":
                yyparser.yylval = new ParserVal(symbol);
                return Parser.RELOP;
            case "=":
                return Parser.RELOP;
            case "+":
            case "-":
            case "*":
            case "/":
                return Parser.OP;
            // Add cases for other symbols
            default:
                return -1; // Not a symbol
        }
    }
    private String LookAhead(int count) throws Exception {
        StringBuilder lookaheadBuffer = new StringBuilder();
        for (int i = 0; i < count; i++) {
            int data = reader.read();
            if (data == -1) {
                return String.valueOf(EOF);
            }
            lookaheadBuffer.append((char) data);
        }
        return lookaheadBuffer.toString();
    }
    public int yylex() throws Exception {
        int state = 0;

        while (true) {
            String c = "";
            switch (state) {
                case 0:
                    c = NextChar(); // Get the next character
                    if (c.equals(String.valueOf(EOF))) {
                        state = 9999;
                        continue;
                    } else if (c.equals("(")) {
                        lexemeBuffer.append(c);
                        yyparser.yylval = new ParserVal(lexemeBuffer.toString());
                        lexemeBuffer.setLength(0);  // Clear the buffer
                        return Parser.LPAREN;
                    } else if (Character.isLetter(c.charAt(0))) {
                        lexemeBuffer.append(c);
                        state = 20; // Move to state for reading identifiers
                        continue;
                    } else if (c.equals(":")) {
                        lexemeBuffer.append(c);
                        state = 30; // Move to state for handling colon in FUNC case
                        continue;
                    } else if (c.equals("\n")) {
                        lineno++;
                        column = 1;
                        continue;
                    } else if (Character.isWhitespace(c.charAt(0))) {
                        continue; // Skip whitespace
                    } else {
                        // Check for symbols
                        int symbolToken = checkSymbol(c);
                        if (symbolToken != -1) {
                            lexemeBuffer.append(c);
                            yyparser.yylval = new ParserVal(lexemeBuffer.toString());
                            lexemeBuffer.setLength(0);  // Clear the buffer
                            return symbolToken;
                        } else {
                            return Fail();
                        }
                    }
                case 10: // State for reading numbers
                    c = NextChar();
                    if (Character.isDigit(c.charAt(0)) || (c.equals(".") && lexemeBuffer.indexOf(".") == -1)) {
                        lexemeBuffer.append(c);
                        // Continue reading numbers
                        if (lexemeBuffer.length() >= 10 && lexemeBuffer.indexOf(".") == lexemeBuffer.lastIndexOf(".")) {
                            // Switch to double buffer
                            doubleBuffer.setLength(0);
                            doubleBuffer.append(lexemeBuffer.substring(0, 10));
                            lexemeBuffer.setLength(0);
                            yyparser.yylval = new ParserVal();
                            yyparser.yylval.ival = (int) Double.parseDouble(doubleBuffer.toString());
                            yyparser.yylval.obj = Double.parseDouble(doubleBuffer.toString());
                            return Parser.NUM;
                        }
                    } else {
                        // Finish reading numbers
                        if (lexemeBuffer.length() > 0) {
                            yyparser.yylval = new ParserVal();
                            yyparser.yylval.ival = (int) Double.parseDouble(lexemeBuffer.toString());
                            yyparser.yylval.obj = Double.parseDouble(lexemeBuffer.toString());
                            lexemeBuffer.setLength(0); // Clear the buffer
                            state = 0;
                            return Parser.NUM;
                        }
                    }
                    break;
                case 20: // State for reading identifiers
                    c = NextChar();
                    while (Character.isLetterOrDigit(c.charAt(0)) || c.equals("_")) {
                        lexemeBuffer.append(c);
                        // Continue reading identifiers
                        c = NextChar();
                    }
                    if (Character.isLetterOrDigit(c.charAt(0)) || c.equals("_")) {
                        lexemeBuffer.append(c);
                        // Continue reading identifiers
                    } else {
                        // Finish reading identifiers
                        String identifier = lexemeBuffer.toString();
                        lexemeBuffer.setLength(0); // Clear the buffer
                        int keywordToken = checkKeyword(identifier);
                        if (keywordToken != -1) {
                            yyparser.yylval = new ParserVal();
                            yyparser.yylval.obj = identifier;
                            return keywordToken;
                        } else {
                            yyparser.yylval = new ParserVal();
                            yyparser.yylval.obj = identifier;
                            return Parser.ID;
                        }
                    }
                    // Check if it's a type declaration "::"
                    String lookahead = LookAhead(1);
                    if (lookahead.equals(":")) {
                        String nextChar = NextChar();
                        if (nextChar.equals(":")) {
                            lexemeBuffer.append("::");
                            yyparser.yylval = new ParserVal(lexemeBuffer.toString());
                            lexemeBuffer.setLength(0); // Clear the buffer
                            return Parser.TYPEOF;
                        } else {
                            // Not "::", process the current character
                            doubleBuffer.insert(0, nextChar); // Put back the character for further processing
                            yyparser.yylval = new ParserVal(lexemeBuffer.toString());
                            lexemeBuffer.setLength(0); // Clear the buffer
                            // Adjust this part to handle the COLON case correctly
                            return Parser.COLON; // Assuming that COLON should be returned here
                        }
                    }
                    break;
                case 30: // State for handling colon in FUNC case
                    String nextChar = NextChar();
                    while (Character.isWhitespace(nextChar.charAt(0))) {
                        // Ignore whitespace
                        nextChar = NextChar();
                    }

                    if (nextChar.equals(":")) {
                        lexemeBuffer.append(nextChar);
                        state = 31; // Move to state for handling "::"
                    } else if (nextChar.equals("=")) {
                        lexemeBuffer.append(nextChar);
                        state = 32; // Move to state for handling ":="
                    } else {
                        // Just a colon
                        yyparser.yylval = new ParserVal(lexemeBuffer.toString());
                        lexemeBuffer.setLength(0);  // Clear the buffer
                        return Parser.COLON;
                    }
                    break;

                case 31: // State for handling "::"
                    String doubleColon = lexemeBuffer.toString() + "::";
                    String afterDoubleColon = doubleColon + NextChar();
                    if (checkKeyword(afterDoubleColon) == -1) {
                        // Not a keyword, process the current character and go back to COLON state
                        doubleBuffer.insert(0, afterDoubleColon.substring(doubleColon.length()));
                        yyparser.yylval = new ParserVal(doubleColon);
                        lexemeBuffer.setLength(0); // Clear the buffer
                        state = 0; // Go back to the initial state
                    } else {
                        // It's a keyword, return the TYPEOF token
                        yyparser.yylval = new ParserVal(doubleColon);
                        lexemeBuffer.setLength(0); // Clear the buffer
                        return Parser.TYPEOF;
                    }
                    break;
                case 9999:
                    return 0; // EOF
            }
        }
    }
}